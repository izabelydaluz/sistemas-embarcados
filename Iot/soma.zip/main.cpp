/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float n1,n2, soma;
    
    printf("informe um valor:");
    scanf("%f",&n1);
    
    printf("informe outro valor:");
    scanf("%f",&n2);
    
    soma = n1+n2;
    
    if (soma >= 10){
        printf("o resultado da conta é de:=%f", soma);
        
    }
    else{
        printf("o valor da conta é de:=%f", soma);
    }
    return 0;
}
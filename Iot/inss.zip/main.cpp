/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

int main()
{   float salario;

    printf("informe seu salario por favor:");
    scanf("%f",&salario);
    
    if (salario <= 600){
        printf("voce não paga nada de INSS");
    }
    if (salario <= 1200){
        salario = salario-salario*20/100;
        printf("seu salario com desconto é de: = %.2f",salario);
    }
    if (salario<= 2000){
        salario = salario -salario*25/100;
        printf("seu salario com desconto é de: = %.2f",salario);
    }
    if (salario >= 2000){
        salario = salario-salario*30/100;
        printf("seu salario com desconto é de: = %.2f",salario);
    }

    return 0;
}
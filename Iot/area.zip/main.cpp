/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdio.h>
#define PI 3.14159
int main()
{
    printf("Hello World");


    //calculo da area
    float area, raio;
    raio = 12.00;
    area = PI * raio *raio;
    printf("Area = %f",  area);
    return 0;
}